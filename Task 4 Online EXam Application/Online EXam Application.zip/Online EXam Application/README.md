# Quiz_App
This is a Udacity Quiz App Project. In this Object-Oriented Programming and Basic Functionality of the Android GUI like Check Box, Radio Button and Edit Text implemented . 
